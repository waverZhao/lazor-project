"""Check that packaged evidence, source fingerprints and trial artifacts agree."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys
from xml.etree import ElementTree

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def check(condition, description):
    if not condition:
        raise RuntimeError(description)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    folder = ROOT / "results/recorded_run"
    result = json.loads((folder / "results.json").read_text("utf-8"))
    plan = json.loads((folder / "run_plan.json").read_text("utf-8"))
    manifest = json.loads((ROOT / "cases/manifest.json").read_text("utf-8"))
    rows = result["trials"]
    raw = [json.loads(line) for line in (folder / "results.jsonl").read_text("utf-8").splitlines()]
    check(rows == raw, "Aggregate JSON differs from append-only trial log")
    check(len(rows) == len(plan["schedule"]) == 108, "Expected 108 recorded trials")
    check(len(manifest) == 25, "Expected 25 cases")
    check(len({row["trial_id"] for row in rows}) == 108, "Duplicate trial identifiers")
    check([row["trial_id"] for row in rows] == [row["trial_id"] for row in plan["schedule"]], "Execution differs from planned order")
    check(Counter(row["phase"] for row in rows) == {"base": 100, "extended": 8}, "Phase count mismatch")
    for case in manifest:
        check(sha256(ROOT / case["path"]) == case["sha256"], "Manifest input hash mismatch")
    for path, expected in result["input_hashes"].items():
        check(sha256(ROOT / path) == expected, "Input changed since benchmark")
    for name, expected in result["harness_hashes"].items():
        check(sha256(ROOT / name) == expected, "Benchmark harness changed since execution")
    check(result["source_unchanged"], "Tested source changed during benchmark")
    check(result["source_hashes_before"] == result["source_hashes_after"], "Source before/after mismatch")
    for relative, expected in result["source_hashes_before"].items():
        check(sha256(ROOT / "tested_source" / relative) == expected, "Snapshot source hash mismatch")
    source = json.loads((ROOT / "source_snapshot.json").read_text("utf-8"))
    for entry in source["files"]:
        check(sha256(ROOT / "tested_source" / entry["path"]) == entry["sha256"], "Original-copy fingerprint mismatch")
    svg_count = 0
    repeated = defaultdict(list)
    for row, planned in zip(rows, plan["schedule"]):
        check(row["algorithm"] == planned["algorithm"] and row["budget_seconds"] == planned["budget"], "Planned parameters differ from execution")
        trial = folder / "trials" / row["trial_id"]
        check(json.loads((trial / "record.json").read_text("utf-8")) == row, "Per-trial record differs from aggregate")
        if row["phase"] == "base":
            repeated[(row["case_id"], row["algorithm"])].append(row["status"])
        if row["status"] == "solved":
            check(row["verified"] and row["roundtrip_verified"], "A solution was not fully validated")
            check(all((trial / f"solution.{extension}").is_file() for extension in ("txt", "svg", "bff")), "Missing solution artifact")
            ElementTree.parse(trial / "solution.svg")
            svg_count += 1
        else:
            check(not list(trial.glob("solution.*")), "An unsuccessful trial retained solution artifacts")
    summary = {
        "status": "passed", "cases_checked": len(manifest), "trials_checked": len(rows),
        "base_trials": 100, "extended_trials": 8, "svg_documents_parsed": svg_count,
        "base_case_algorithm_pairs": len(repeated),
        "pairs_with_matching_repeat_status": sum(len(set(statuses)) == 1 for statuses in repeated.values()),
        "source_files_matched_to_original_snapshot": len(source["files"]),
        "trial_status_counts": dict(Counter(row["status"] for row in rows)),
        "note": "Evidence consistency audit; a passed audit does not turn timeouts into solved cases."
    }
    (ROOT / "package_validation.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
