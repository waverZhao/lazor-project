"""Reproduce the second Lazor stress test using only Python's standard library."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import statistics
import subprocess
import sys
from time import perf_counter
import traceback

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes(project):
    return {str(p.relative_to(project)).replace("\\", "/"): digest(p)
            for p in sorted(project.rglob("*.py"))}


def worker(args):
    """One isolated trial; checkpoints distinguish search from later validation."""
    record = {"stage": "imports", "status": "error", "verified": False,
              "roundtrip_verified": False}
    save(args.record, record)
    try:
        sys.path.insert(0, str(args.project.resolve()))
        from file_io import load_bff
        from search import solve_dfs, solve_targets
        from block_laser import simulate
        from output import write_bff, write_svg, write_report
        from independent_oracle import verify, trace

        solve = {"targets": solve_targets, "dfs": solve_dfs}[args.algorithm]
        record["stage"] = "load_and_search"
        save(args.record, record)
        start = perf_counter()
        puzzle = load_bff(args.case)
        original = (puzzle.grid, dict(puzzle.block_counts), puzzle.lasers, puzzle.targets)
        load_seconds = perf_counter() - start
        outcome = solve(puzzle, timeout=max(0.0, args.timeout - load_seconds))
        measured = perf_counter() - start
        record.update(stage="verification", status=outcome.status,
                      solver_status=outcome.status, load_seconds=load_seconds,
                      load_and_solve_seconds=measured,
                      solver_reported_seconds=outcome.elapsed_seconds,
                      budget_overrun_seconds=max(0.0, measured - args.timeout),
                      reason=outcome.reason,
                      candidates_tested=outcome.candidates_tested,
                      states_expanded=outcome.states_expanded,
                      ray_states_processed=outcome.ray_states_processed)
        save(args.record, record)
        assert original == (puzzle.grid, puzzle.block_counts, puzzle.lasers, puzzle.targets), "Input puzzle mutated"
        assert outcome.status in ("solved", "no_solution", "timeout"), "Unexpected status"
        if args.expected != "unknown" and outcome.status != "timeout":
            assert outcome.status == args.expected, "Result contradicts independently established case status"
        verification_start = perf_counter()
        if outcome.status == "solved":
            assert outcome.solution is not None
            record["verification_metrics"] = verify(puzzle, outcome.solution)
            record["verified"] = True
            record["verification_seconds"] = perf_counter() - verification_start
            record["stage"] = "export_and_reload"
            save(args.record, record)
            export_start = perf_counter()
            destination = args.record.parent
            bff = write_bff(outcome.solution, destination / "solution.bff", search=outcome)
            write_svg(outcome.solution, destination / "solution.svg", search=outcome)
            write_report(outcome.solution, destination / "solution.txt", search=outcome)
            restored = load_bff(bff)
            assert restored.grid == outcome.solution.layout.grid, "Export changed layout"
            assert restored.lasers == puzzle.lasers, "Export changed sources"
            assert restored.targets == puzzle.targets, "Export changed targets"
            assert not any(restored.block_counts.values()), "Export retained movable inventory"
            replay = simulate(restored)
            verify(restored, replay)
            points, segments = trace(restored.grid, [(r.x, r.y, r.vx, r.vy) for r in restored.lasers])
            assert points == outcome.solution.visited_points
            assert segments == frozenset(outcome.solution.segments)
            record["roundtrip_verified"] = True
            record["export_reload_seconds"] = perf_counter() - export_start
        else:
            assert outcome.solution is None, "Unsolved result contains a solution"
            if args.expected != "unknown" and outcome.status == args.expected:
                record["expected_status_verified"] = True
        record["stage"] = "complete"
    except Exception as exc:
        record["failed_stage"] = record["stage"]
        record.update(status="error", stage="complete", error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc())
    save(args.record, record)
    return int(record["status"] == "error")


def summarize(rows):
    result = {}
    for phase in sorted({r["phase"] for r in rows}):
        for algorithm in ("targets", "dfs"):
            selected = [r for r in rows if r["phase"] == phase and r["algorithm"] == algorithm]
            solved = [r["load_and_solve_seconds"] for r in selected if r["status"] == "solved"]
            result[f"{phase}/{algorithm}"] = {
                "trials": len(selected), "statuses": dict(Counter(r["status"] for r in selected)),
                "verified_solutions": sum(bool(r.get("verified")) for r in selected),
                "roundtrip_verified": sum(bool(r.get("roundtrip_verified")) for r in selected),
                "solved_time_median_seconds": statistics.median(solved) if solved else None,
                "solved_time_max_seconds": max(solved) if solved else None,
                "max_budget_overrun_seconds": max((r.get("budget_overrun_seconds", 0) for r in selected), default=0),
            }
    return result


def report_text(result):
    rows = result["trials"]
    lines = ["LAZOR SOLVER - SECOND STRESS TEST", "=" * 70,
             f"Completed (UTC): {result['completed_utc']}",
             f"Environment: Python {result['python']} | {result['platform']}",
             f"Cases: {result['case_count']} | Trials: {len(rows)}",
             "", "METHOD", "-" * 70,
             f"Selected categories: {result['category_counts']}",
             "The full suite contains fresh 8x8, 16x16 and 32x32 witness-backed",
             "reflector/mixed cases, archived stress inputs, and small optical controls.",
             f"Base: each case x 2 algorithms x {result['config']['repeats']} repetitions; {result['config']['base_budget_seconds']} seconds per trial.",
             f"Extension: {result['config']['extended_trials']} preselected trials; {result['config']['extended_budget_seconds']} seconds each.",
             "See run_plan.json for exact parameters; it was written before solving.",
             "Each trial uses a fresh process and a unique artifact directory.",
             "Algorithm order is reversed on repetition 2. Trials run serially.",
             "Time includes reading the BFF and solving, but excludes imports, process",
             "startup, independent validation, export, and reload validation.",
             "A separate process watchdog uses budget + 15 seconds for all stages.",
             "Its stage is recorded; watchdog stops are not solver no-solution proofs.",
             "", "RESULTS", "-" * 70,
             "Phase/algorithm      Trials Solved No-solution Timeout Errors Watchdog"]
    for key, data in result["summary"].items():
        c = data["statuses"]
        lines.append(f"{key:<22} {data['trials']:>5} {c.get('solved', 0):>6} {c.get('no_solution', 0):>11} {c.get('timeout', 0):>7} {c.get('error', 0):>6} {c.get('outer_watchdog', 0):>8}")
    solved = [r for r in rows if r["status"] == "solved"]
    errors = [r for r in rows if r["status"] in ("error", "outer_watchdog")]
    lines += ["", f"Independently validated solutions: {sum(bool(r.get('verified')) for r in solved)}/{len(solved)}",
              f"Export/reload checks passed: {sum(bool(r.get('roundtrip_verified')) for r in solved)}/{len(solved)}",
              f"Errors or watchdog terminations: {len(errors)}",
              "", "CASE DETAIL (base repetitions followed by extension)", "-" * 70]
    for row in rows:
        elapsed = row.get("load_and_solve_seconds")
        duration = f"{elapsed:.6f}s" if elapsed is not None else "unavailable"
        lines.append(f"{row['trial_id']} | {row['status']} | {duration}")
        if row.get("error"):
            lines.append("  " + row["error"])
    lines += ["", "INTERPRETATION AND LIMITS", "-" * 70,
              "A timeout means the search did not finish within its cooperative budget;",
              "it is neither a wrong answer nor proof that no solution exists.",
              "Known-solvable generated cases have separately saved, independently",
              "checked witnesses. Solvers receive only BFF inputs, never the witnesses.",
              "Every returned solution is checked for legal placement, full inventory,",
              "fixed-cell preservation, complete target coverage, points and segments.",
              "Exported BFFs must preserve the exact layout, sources and targets and",
              "contain no movable inventory; their geometry is checked again on reload.",
              "Witness generation uses optical acceptance criteria, not solver results.",
              "These random fixtures are a synthetic workload, not a representative",
              "sample of public game levels. Random generation does not imply difficulty.",
              "Repetitions share inputs and are not independent correctness cases.",
              "Timeout durations are censored; they are not completed solution times.",
              "No memory benchmark, absolute performance guarantee, or universal",
              "speedup claim is made. Counters have different meanings by algorithm.",
              "", "WORK COMPLETED", "-" * 70,
              "Prepared reproducible fixtures, a separate ray-geometry verifier, an",
              "isolated serial benchmark runner, recorded raw results and source hashes,",
              "and validated exported solutions. Prepared and executed with Codex",
              "assistance. The tested solver source was copied unchanged.", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=ROOT / "tested_source")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--timeout", type=float, default=2.0)
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--extended-timeout", type=float, default=5.0)
    parser.add_argument("--skip-extended", action="store_true")
    parser.add_argument("--only", nargs="*")
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--case", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--record", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--algorithm", choices=("targets", "dfs"), help=argparse.SUPPRESS)
    parser.add_argument("--expected", default="unknown", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not __debug__:
        parser.error("Run without -O or PYTHONOPTIMIZE so all validation checks remain enabled")
    if args.worker:
        return worker(args)
    import math
    if not all(math.isfinite(x) and x > 0 for x in (args.timeout, args.extended_timeout)) or args.repeats < 1:
        parser.error("Budgets must be finite and positive; repeats must be positive")
    if not (args.project / "search.py").is_file():
        parser.error("--project must point to the integrated project containing search.py")
    cases = json.loads((ROOT / "cases/manifest.json").read_text("utf-8"))
    if args.only:
        cases = [c for c in cases if c["id"] in args.only]
        if {c["id"] for c in cases} != set(args.only):
            parser.error("An --only case ID was not found in the manifest")
    out = args.output or ROOT / "results" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    if out.exists():
        parser.error("Output directory already exists; choose a new directory to preserve prior evidence")
    out.mkdir(parents=True)
    plan = []
    for repetition in range(1, args.repeats + 1):
        algorithms = ("targets", "dfs") if repetition % 2 else ("dfs", "targets")
        for case in cases:
            for algorithm in algorithms:
                plan.append(dict(case=case, phase="base", repetition=repetition,
                                 algorithm=algorithm, budget=args.timeout))
    if not args.skip_extended:
        extended = [c for c in cases if c["category"] == "archived_stress" and c["width"] >= 20]
        for family in ("reflect", "mixed"):
            options = sorted((c for c in cases if c["category"] == "generated" and c["width"] == 32 and c["family"] == family), key=lambda c: c["id"])
            extended += options[:1]
        for case in extended:
            for algorithm in ("targets", "dfs"):
                plan.append(dict(case=case, phase="extended", repetition=1,
                                 algorithm=algorithm, budget=args.extended_timeout))
    for trial in plan:
        trial["trial_id"] = f"{trial['phase']}_{trial['case']['id']}_{trial['algorithm']}_r{trial['repetition']}"
    metadata = dict(started_utc=datetime.now(timezone.utc).isoformat(), python=platform.python_version(),
                    platform=platform.platform(), machine=platform.machine(), processor=platform.processor(),
                    project=str(args.project.resolve()), case_count=len(cases),
                    category_counts=dict(Counter(c['category'] for c in cases)),
                    config=dict(repeats=args.repeats, base_budget_seconds=args.timeout,
                                extended_budget_seconds=args.extended_timeout,
                                extended_trials=sum(t['phase'] == 'extended' for t in plan)),
                    source_hashes_before=source_hashes(args.project),
                    harness_hashes={p.name: digest(p) for p in sorted(ROOT.glob("*.py"))},
                    input_hashes={c["path"]: digest(ROOT / c["path"]) for c in cases},
                    manifest_sha256=digest(ROOT / "cases/manifest.json"),
                    planned_trials=len(plan), trials=[])
    save(out / "run_plan.json", {"metadata": metadata, "schedule": plan})
    wall_start = perf_counter()
    for index, trial in enumerate(plan, 1):
        case = trial["case"]
        record_path = out / "trials" / trial["trial_id"] / "record.json"
        record_path.parent.mkdir(parents=True)
        command = [sys.executable, "-B", str(Path(__file__).resolve()), "--worker",
                   "--project", str(args.project.resolve()), "--case", str((ROOT / case["path"]).resolve()),
                   "--algorithm", trial["algorithm"], "--timeout", str(trial["budget"]),
                   "--expected", case["expected_status"], "--record", str(record_path.resolve())]
        start = perf_counter()
        try:
            completed = subprocess.run(command, capture_output=True, text=True, timeout=trial["budget"] + 15)
            row = json.loads(record_path.read_text("utf-8")) if record_path.exists() else {"status": "error", "error": "Worker produced no record"}
            row["worker_exit_code"] = completed.returncode
            if completed.returncode != 0 and row.get("status") != "error":
                row.update(status="error", error="Worker exited abnormally", failed_stage=row.get("stage"))
            if completed.stdout or completed.stderr:
                (record_path.parent / "worker.log").write_text(completed.stdout + completed.stderr, encoding="utf-8")
        except subprocess.TimeoutExpired:
            row = json.loads(record_path.read_text("utf-8")) if record_path.exists() else {"stage": "startup"}
            row.update(status="outer_watchdog", watchdog_stage=row.get("stage"),
                       error="Outer process deadline exceeded; termination is not a no-solution proof")
        row.update(trial_id=trial["trial_id"], case_id=case["id"], category=case["category"],
                   width=case["width"], height=case["height"], phase=trial["phase"],
                   repetition=trial["repetition"], algorithm=trial["algorithm"],
                   budget_seconds=trial["budget"], expected_status=case["expected_status"],
                   process_wall_seconds=perf_counter() - start)
        save(record_path, row)
        metadata["trials"].append(row)
        with (out / "results.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        print(f"[{index:03d}/{len(plan)}] {trial['trial_id']}: {row['status']} ({row.get('load_and_solve_seconds', 0):.6f}s)", flush=True)
    metadata.update(completed_utc=datetime.now(timezone.utc).isoformat(),
                    total_process_loop_seconds=perf_counter() - wall_start,
                    source_hashes_after=source_hashes(args.project))
    metadata["source_unchanged"] = metadata["source_hashes_before"] == metadata["source_hashes_after"]
    metadata["summary"] = summarize(metadata["trials"])
    save(out / "results.json", metadata)
    (out / "STRESS_TEST_REPORT.txt").write_text(report_text(metadata), encoding="utf-8")
    print(f"Report: {out / 'STRESS_TEST_REPORT.txt'}", flush=True)
    return int(not metadata["source_unchanged"] or any(r["status"] in ("error", "outer_watchdog") for r in metadata["trials"]))


if __name__ == "__main__":
    raise SystemExit(main())
