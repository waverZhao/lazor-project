LAZOR SOLVER - SECOND STRESS-TEST PACKAGE
=======================================

Purpose
-------
This folder is a self-contained second test record for upload alongside the
project. It contains reproducible stress inputs, the unchanged tested source
snapshot, the benchmark and verification scripts, and recorded evidence.
It documents the test preparation, execution, and findings.

Start with STRESS_TEST_REPORT.txt for the completed run's results. The detailed
machine-readable evidence is results/recorded_run/results.json. The report is
also stored at results/recorded_run/STRESS_TEST_REPORT.txt.

Package contents
----------------
  README.txt                       This guide and reproduction instructions
  STRESS_TEST_REPORT.txt            Human-readable completed-run report
  run_stress.py                    Serial benchmark and export/reload checks
  generate_cases.py                Deterministic fixture generator
  independent_oracle.py            Direct geometric replay and result checker
  audit_package.py                 Recheck recorded evidence and artifact hashes
  package_validation.json          Completed evidence consistency audit
  source_snapshot.json             Original-to-snapshot file fingerprints
  SHA256SUMS.txt                    Checksums of the packaged files
  tested_source/                   Tested project files copied unchanged
  cases/manifest.json              All 25 cases, metadata, paths, and SHA256
  cases/generation_protocol.json   Fixed seeds and optical acceptance criteria
  cases/fixture_validation.json    Fixture and checker sanity-check record
  cases/generated/                 18 new witness-backed synthetic inputs
  cases/archived/                  3 existing stress inputs copied unchanged
  cases/controls/                  4 small optical correctness controls
  cases/witnesses/                 Separate witnesses/control expectation records
  results/recorded_run/            Main run's plan, records, report, and artifacts
  preflight_results/               Four preliminary sanity trials, kept separate
  run_console.log                 Captured progress log of the main execution

The main results folder contains run_plan.json, results.json, results.jsonl,
and a trials/ directory. Each trial has its own record.json; solved trials
also have solution.bff, solution.svg, and solution.txt. A worker.log is saved
when a worker produces console output. Empty worker output need not have a log.

Test design
-----------
There are 25 distinct inputs:

  * 18 fresh cases: sizes 8x8, 16x16, and 32x32; reflector-only or mixed
    A/B/C movable inventories; three fixed seeds per size/family combination.
    They include unavailable cells, fixed blocks, and two boundary sources.
  * 3 archived stress inputs of sizes 10x10, 20x20, and 32x32.
  * 4 controls: splitter, blocked target, reachable mirror loop, and isolated
    mirror loop. Two controls are solvable; two have a fixed unsatisfiable layout.

The recorded full schedule contains 108 trials:

  Base:      25 cases x 2 algorithms x 2 repetitions = 100 trials,
             with a 2-second cooperative budget per trial.
  Extension: 4 preselected large cases x 2 algorithms = 8 trials,
             with a 5-second cooperative budget per trial.

The extension uses the two archived cases of width at least 20 and the
lexicographically first fresh 32x32 case from each family. This selection is
defined before solving and is not based on the observed results. The exact
schedule is saved in run_plan.json before execution.

Both Target-X (targets) and baseline DFS (dfs) are tested. Trials run serially
in fresh child processes. Algorithm order reverses for the second repetition.
The four preflight trials are separate sanity checks and are not included in
the 108-trial main result totals.

The measured load_and_solve_seconds covers input reading and search. It
excludes imports, interpreter startup, independent verification, output
writing, and reload checks. process_wall_seconds records the broader child
process duration separately. A process watchdog allows the cooperative budget
plus 15 seconds for all worker stages; its termination is recorded separately.

Verification and fixture provenance
-----------------------------------
Fresh inputs are constructed from separately saved valid placements. A case
is accepted only when direct ray tracing finds at least four reachable points
absent from the unplaced original board and at least max(12, size) directed
segments. Targets exclude source points. Selection never uses solver runtime
or outcome. All 18 generated cases are included. Solvers receive the BFF
inputs only; they are not given the witness placements.

The fixture validation record checks input hashes, independently replays
witnesses/control expectations, confirms byte-identical regeneration of the
fresh inputs, and checks that corrupted segment records are rejected. The
generator and fixture validation do not call either solver.

Every returned solution is checked for legal placement, exact inventory use,
preservation of fixed cells, complete target coverage, and exact agreement
of visited points and directed segments. Exported BFFs are reloaded; layout,
sources, targets, zero remaining inventory, and ray geometry are checked again.

The geometric oracle is adapted from the project's existing
tests/test_search_integration.py::reference_trace. It does not import the
production search, transition, block-interaction, or simulator implementation.
It is an independent replay implementation relative to production code, not
an independently developed physical specification or a separate third-party
validation authority.

Archived inputs are marked expected_status="unknown" because no independently
verified witness is supplied for them. A solved result can establish a valid
solution; an unfinished search cannot establish unsatisfiability.

Reproduce the benchmark
----------------------
Use Python 3.9 or newer, as required by the integrated source. No third-party
packages are required. The recorded run used Python 3.12.14 on Windows.

Open a terminal in this extracted package folder, then run:

  python -B "run_stress.py"

The default project is the included tested_source folder. A new timestamped
output directory is created under results/, preserving the recorded evidence.
Do not use -O or PYTHONOPTIMIZE: validation assertions must remain enabled.
The script rejects an existing output directory.

To choose a new output directory explicitly:

  python -B "run_stress.py" --output "results/my_rerun"

To test another copy of the same integrated project layout:

  python -B "run_stress.py" --project "C:\path\to\integrated-project" --output "results/other_project_run"

The --project folder must contain search.py and the other integrated modules.
Changing the project changes what is being tested; record that distinction
when reporting results.

To recheck the included recorded evidence:

  python -B "audit_package.py"

If the default python command is unavailable, use a compatible interpreter's
full path. In PowerShell, for example:

  & "C:\path\to\python.exe" -B "run_stress.py"

To reproduce the fixtures in a fresh location without overwriting the recorded
cases, run:

  python -B "generate_cases.py" --project "tested_source" --output "regenerated_cases"

This creates regenerated_cases/cases/. It reconstructs the fresh cases and
copies archived inputs from the snapshot. The benchmark reads the recorded
cases/manifest.json by default; regeneration does not change those inputs.

Interpretation and limits
-------------------------
  * Timeout means the search was unfinished at its budget. It does not mean
    a wrong answer or proof that a puzzle has no solution.
  * Known-solvable fresh cases have witness evidence even if a solver times out.
  * These synthetic inputs are not a representative sample of all public game
    levels. A random input is not necessarily a difficult input.
  * Repetitions reuse inputs; they are not additional independent test cases.
  * Timeout durations are censored observations, not completed solution times.
  * Search counters have different meanings for the two algorithms and should
    not be treated as directly equivalent units of work.
  * Timing depends on this machine, interpreter, workload, and system load.
    No universal speedup or absolute performance guarantee is claimed.
  * This package does not contain a memory benchmark.

Work performed
--------------
Prepared reproducible fixtures and witnesses; adapted a direct geometric
checker; prepared an isolated serial test runner and a predeclared schedule;
executed checks and recorded raw evidence; checked returned and exported
solutions; and prepared an English report and upload package. Preparation
and execution used Codex assistance. The tested solver files were copied
unchanged.
