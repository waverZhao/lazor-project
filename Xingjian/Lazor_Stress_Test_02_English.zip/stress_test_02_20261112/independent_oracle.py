"""Direct geometric replay, independent of production solver transitions.

Adapted from tests/test_search_integration.py::reference_trace in the tested
project. This is independent of production search/simulation code, not an
independently developed physical specification. No production module is imported.
"""

from collections import Counter


def trace(grid, lasers):
    """Return visited points and directed segments using half-cell geometry."""
    height, width = len(grid), len(grid[0])

    def material(x, y, dx, dy):
        if x % 2 == 0:
            column = (x - 1) // 2 if dx < 0 else x // 2
            row = y // 2
        else:
            column = x // 2
            row = (y - 1) // 2 if dy < 0 else y // 2
        if 0 <= column < width and 0 <= row < height:
            return grid[row][column]
        return "o"

    pending = list(lasers)
    seen, points, segments = set(), set(), set()
    while pending:
        state = tuple(pending.pop())
        if state in seen:
            continue
        seen.add(state)
        x, y, dx, dy = state
        points.add((x, y))
        kind = material(x, y, dx, dy)
        directions = []
        if kind in ("o", "x", "C"):
            directions.append((dx, dy))
        if kind in ("A", "C"):
            directions.append((-dx, dy) if x % 2 == 0 else (dx, -dy))
        for next_dx, next_dy in directions:
            # A ray may not emerge into a neighboring reflector/absorber.
            if material(x, y, next_dx, next_dy) in ("A", "B"):
                continue
            endpoint = (x + next_dx, y + next_dy)
            if 0 <= endpoint[0] <= 2 * width and 0 <= endpoint[1] <= 2 * height:
                segments.add(((x, y), endpoint))
                pending.append((*endpoint, next_dx, next_dy))
    return frozenset(points), frozenset(segments)


def verify(puzzle, simulation):
    """Check inventory, fixed cells, targets, and exact geometric replay."""
    if simulation is None or not simulation.is_solution:
        raise AssertionError("No complete solution was supplied.")
    layout = simulation.layout
    placements = layout.placements
    if len(layout.grid) != puzzle.height or any(
        len(row) != puzzle.width for row in layout.grid
    ):
        raise AssertionError("Solution dimensions differ from input.")
    for position, kind in placements.items():
        if (not isinstance(position, tuple) or len(position) != 2
                or any(type(value) is not int for value in position)):
            raise AssertionError("Placement coordinates must be integer pairs.")
        column, row = position
        if not (0 <= column < puzzle.width and 0 <= row < puzzle.height):
            raise AssertionError("A placement is outside the board.")
        if puzzle.grid[row][column] != "o" or kind not in ("A", "B", "C"):
            raise AssertionError("A placement violates the original board.")
    counts = Counter(placements.values())
    if any(counts[kind] != puzzle.block_counts.get(kind, 0) for kind in "ABC"):
        raise AssertionError("Movable inventory is not used exactly.")
    if any(layout.remaining_blocks.values()) or not layout.complete:
        raise AssertionError("The returned layout is incomplete.")
    for row, cells in enumerate(puzzle.grid):
        for column, original in enumerate(cells):
            expected = placements.get((column, row), "o") if original == "o" else original
            if layout.grid[row][column] != expected:
                raise AssertionError("Solution changed fixed cells or its placement grid.")
    lasers = [(ray.x, ray.y, ray.vx, ray.vy) for ray in puzzle.lasers]
    points, segments = trace(layout.grid, lasers)
    if not puzzle.targets <= points:
        raise AssertionError("Independent replay misses a target.")
    if simulation.visited_points != points:
        raise AssertionError("Visited points disagree with independent replay.")
    if frozenset(simulation.segments) != segments:
        raise AssertionError("Segments disagree with independent replay.")
    if simulation.hit_targets != puzzle.targets & points:
        raise AssertionError("Reported hit targets are inconsistent.")
    if simulation.missed_targets != puzzle.targets - points:
        raise AssertionError("Reported missed targets are inconsistent.")
    return {"visited_points": len(points), "segments": len(segments),
            "targets_hit": len(puzzle.targets), "placed_blocks": len(placements)}
