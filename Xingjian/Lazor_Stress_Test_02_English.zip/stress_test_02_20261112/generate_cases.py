"""Reproduce the second stress-test suite without running either solver.

Selection uses fixed optical criteria only. Every generated fixture is included;
no case is selected or discarded using solver runtime or outcome.
"""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import random
import shutil
import sys

from independent_oracle import trace

BASE_SEEDS = (731947, 824633, 915721)
SIZES = (8, 16, 32)
FAMILIES = ("reflect", "mixed")
MAX_ATTEMPTS = 2000


def bff_text(grid, inventory, lasers, targets, comment):
    lines = ["# " + comment, "GRID START"]
    lines.extend(" ".join(row) for row in grid)
    lines.extend(["GRID STOP", ""])
    lines.extend(f"{kind} {inventory.get(kind, 0)}" for kind in "ABC")
    lines.extend("L " + " ".join(map(str, laser)) for laser in lasers)
    lines.extend(f"P {x} {y}" for x, y in sorted(targets))
    return "\n".join(lines) + "\n"


def known_solvable_case(size, family, base_seed):
    seed = base_seed * 1000 + size * 10 + int(family == "mixed")
    rng = random.Random(seed)
    lasers = [(0, 2 * size - 1, 1, -1), (2 * size, 1, -1, 1)]
    area = size * size
    inventory = ({"A": round(area * 0.15), "B": 0, "C": 0}
                 if family == "reflect" else
                 {"A": round(area * 0.10), "B": max(1, round(area * 0.02)),
                  "C": max(1, round(area * 0.05))})
    for attempt in range(1, MAX_ATTEMPTS + 1):
        grid = [["o"] * size for _ in range(size)]
        positions = [(column, row) for row in range(size) for column in range(size)]
        rng.shuffle(positions)
        forbidden = round(area * 0.06)
        fixed = max(1, round(area * 0.02))
        for column, row in positions[:forbidden]:
            grid[row][column] = "x"
        for column, row in positions[forbidden:forbidden + fixed]:
            grid[row][column] = "A" if family == "reflect" else rng.choice("ABC")
        remaining = positions[forbidden + fixed:]
        placement = {}
        cursor = 0
        for kind in "ABC":
            for position in remaining[cursor:cursor + inventory[kind]]:
                placement[position] = kind
            cursor += inventory[kind]
        witness_grid = [row[:] for row in grid]
        for (column, row), kind in placement.items():
            witness_grid[row][column] = kind
        points, segments = trace(witness_grid, lasers)
        baseline_points, _ = trace(grid, lasers)
        extra_points = sorted(points - baseline_points)
        if len(extra_points) < 4 or len(segments) < max(12, size):
            continue
        # Guarantee at least four targets need a changed optical path.
        required = rng.sample(extra_points, min(8, len(extra_points)))
        other = sorted(points - set(required) - {(laser[0], laser[1]) for laser in lasers})
        targets = set(required + rng.sample(other, min(24 - len(required), len(other))))
        if not targets <= points:
            raise AssertionError("Generator selected an unreachable target.")
        if Counter(placement.values()) != Counter({k: v for k, v in inventory.items() if v}):
            raise AssertionError("Generated inventory differs from its witness.")
        if any(grid[row][column] != "o" for column, row in placement):
            raise AssertionError("A witness attempts to replace an unavailable or fixed cell.")
        if targets & {(laser[0], laser[1]) for laser in lasers}:
            raise AssertionError("Generated targets may not include source points.")
        return {"grid": grid, "inventory": inventory, "lasers": lasers,
                "targets": sorted(targets), "placements": placement, "seed": seed,
                "base_seed": base_seed, "generation_attempt": attempt,
                "witness_visited_points": len(points), "witness_segments": len(segments),
                "targets_beyond_unplaced_board": len(targets - baseline_points),
                "fixed_blocks": fixed, "forbidden_cells": forbidden}
    raise RuntimeError(f"No acceptable optical fixture for {size}/{family}/{seed}.")


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def generate(destination: Path, project_root: Path):
    """Write 25 fixtures and return package-relative manifest records."""
    destination, project_root = Path(destination).resolve(), Path(project_root).resolve()
    sys.path.insert(0, str(project_root))
    from file_io import load_bff

    case_dir = destination / "cases"
    for name in ("generated", "archived", "controls", "witnesses"):
        (case_dir / name).mkdir(parents=True, exist_ok=True)
    manifest = []

    def record(path, category, expected_status, seed=None, **extra):
        puzzle = load_bff(path)
        entry = {"id": path.stem, "path": path.relative_to(destination).as_posix(),
                 "category": category, "size": puzzle.width,
                 "width": puzzle.width, "height": puzzle.height,
                 "inventory": dict(puzzle.block_counts), "targets": len(puzzle.targets),
                 "sources": len(puzzle.lasers), "expected_status": expected_status,
                 "seed": seed, "sha256": sha256(path.read_bytes()).hexdigest(), **extra}
        manifest.append(entry)
        return puzzle

    for size in SIZES:
        for family in FAMILIES:
            for base_seed in BASE_SEEDS:
                data = known_solvable_case(size, family, base_seed)
                name = f"fresh_{family}_{size}_seed{data['seed']}"
                path = case_dir / "generated" / f"{name}.bff"
                path.write_text(bff_text(data["grid"], data["inventory"], data["lasers"],
                                         data["targets"],
                                         f"Fresh known-solvable stress case: {name}; witness stored separately."),
                                encoding="utf-8")
                witness_path = case_dir / "witnesses" / f"{name}.json"
                write_json(witness_path, {
                    "case_id": name,
                    "placements": [{"column": column, "row": row, "kind": kind}
                                   for (column, row), kind in sorted(data["placements"].items())],
                    "independent_visited_points": data["witness_visited_points"],
                    "independent_segments": data["witness_segments"],
                    "targets_reached": len(data["targets"]),
                    "note": "Not supplied to either solver; proves the generated input is solvable.",
                })
                record(path, "generated", "solved", data["seed"],
                       family=family, base_seed=base_seed,
                       generation_attempt=data["generation_attempt"],
                       witness_path=witness_path.relative_to(destination).as_posix(),
                       witness_segments=data["witness_segments"],
                       targets_beyond_unplaced_board=data["targets_beyond_unplaced_board"],
                       fixed_blocks=data["fixed_blocks"], forbidden_cells=data["forbidden_cells"])

    archived_paths = [
        "examples/generated/hard_reflect_10.bff",
        "examples/generated/stress_timeouts/extended_tight_20_seed202611352003.bff",
        "examples/generated/stress_timeouts/extended_reflect_32_seed202611053203.bff",
    ]
    for relative in archived_paths:
        source = project_root / relative
        target = case_dir / "archived" / source.name
        shutil.copyfile(source, target)
        record(target, "archived_stress", "unknown", source_relative_path=relative,
               expected_status_note="No independently verified witness is supplied for this archived fixture.")

    controls = [
        ("control_splitter", [["o", "o"], ["o", "o"]], {"A": 0, "B": 0, "C": 1},
         [(2, 1, -1, 1)], [(1, 2), (3, 2)], {(0, 0): "C"}, "solved"),
        ("control_blocked", [["B"]], {"A": 0, "B": 0, "C": 0},
         [(0, 1, 1, 1)], [(1, 2)], {}, "no_solution"),
        ("control_reachable_loop", [["x", "A", "x"], ["A", "x", "A"], ["x", "A", "x"]],
         {"A": 0, "B": 0, "C": 0}, [(3, 2, 1, -1)],
         [(3, 2), (4, 3), (3, 4), (2, 3)], {}, "solved"),
        ("control_isolated_loop", [["x", "A", "x"], ["A", "x", "A"], ["x", "A", "x"]],
         {"A": 0, "B": 0, "C": 0}, [(0, 1, -1, -1)], [(3, 2)], {}, "no_solution"),
    ]
    for name, grid, inventory, lasers, targets, placement, expected in controls:
        solved_grid = [row[:] for row in grid]
        for (column, row), kind in placement.items():
            solved_grid[row][column] = kind
        points, segments = trace(solved_grid, lasers)
        if (set(targets) <= points) != (expected == "solved"):
            raise AssertionError(f"Control expectation does not match independent replay: {name}")
        if expected == "no_solution" and (placement or any(inventory.values())):
            raise AssertionError("An unsolved control requires exhaustive proof or fixed layout.")
        path = case_dir / "controls" / f"{name}.bff"
        path.write_text(bff_text(grid, inventory, lasers, targets,
                                "Control adapted from the project's existing algorithm tests."),
                        encoding="utf-8")
        witness_path = case_dir / "witnesses" / f"{name}.json"
        write_json(witness_path, {
            "case_id": name, "expected_status": expected,
            "placements": [{"column": column, "row": row, "kind": kind}
                           for (column, row), kind in sorted(placement.items())],
            "independent_segments": len(segments),
            "targets_reached": len(set(targets) & points),
            "expectation_basis": "Independent replay of a witness" if expected == "solved"
                                 else "Independent replay; no movable blocks, so the sole layout is unsatisfiable.",
        })
        record(path, "control", expected,
               witness_path=witness_path.relative_to(destination).as_posix())

    if len(manifest) != 25:
        raise AssertionError("Expected exactly 25 fixtures.")
    write_json(case_dir / "manifest.json", manifest)
    write_json(case_dir / "generation_protocol.json", {
        "base_seeds": BASE_SEEDS, "sizes": SIZES, "families": FAMILIES,
        "derived_seed": "base_seed * 1000 + size * 10 + int(family == 'mixed')",
        "max_attempts_per_case": MAX_ATTEMPTS,
        "acceptance_criteria": "At least 4 reachable points absent from the unplaced original board; at least max(12, size) directed ray segments.",
        "target_selection": "Choose up to 8 of the extra points, then sample other reachable non-source points, up to 24 targets total.",
        "inventory": {"reflect": "round(0.15 * n^2) A",
                      "mixed": "round(0.10 * n^2) A, max(1, round(0.02 * n^2)) B, max(1, round(0.05 * n^2)) C"},
        "board": "round(0.06 * n^2) x cells, max(1, round(0.02 * n^2)) fixed blocks; remaining cells are placeable.",
        "selection_uses_solver": False,
        "fresh_count": 18, "archived_count": 3, "control_count": 4,
        "oracle_provenance": "Direct geometric tracer adapted from tests/test_search_integration.py::reference_trace; no production transition/simulation imports.",
    })
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    records = generate(args.output, args.project)
    print(f"Generated {len(records)} cases: 18 fresh, 3 archived, 4 controls.")
    for record in records:
        print(f"{record['id']}: {record['width']}x{record['height']}, "
              f"targets={record['targets']}, expected={record['expected_status']}, "
              f"attempt={record.get('generation_attempt', 'n/a')}")


if __name__ == "__main__":
    main()
