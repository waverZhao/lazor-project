# Full Test of 157 Levels

One serial run of the current Target-X solver with histogram inventory propagation, using a 120-second budget per puzzle. Search received only BFF puzzle inputs and did not read the original JSON answers.

| Metric | Result |
| --- | --- |
| Puzzles | 157 |
| Solved | 157 |
| Timeouts / no solution / errors | 0 / 0 / 0 |
| Independent optical checks passed | 157 |
| Exported BFF reload checks passed | 157 |
| Total reading and solving time | 0.338669 s |
| Median time per puzzle | 0.001484 s |
| 95th-percentile time | 0.005629 s |
| Maximum time | 0.022413 s |
| Puzzles below 5 seconds | 157 / 157 |

Reading and solving time includes BFF reading, validation, graph construction, search, and the solver's final simulation. It excludes Python startup, imports, independent checks, and output writing. Independent verification, text/SVG/BFF exports, BFF replay, and SVG structure checks are timed separately. The full batch, excluding startup and imports, took 0.623138 s.

## Five Slowest Puzzles

| Puzzle | Reading and solving time |
| --- | ---: |
| dejavu_10 | 0.022413 s |
| mad_7 | 0.013886 s |
| dejavu_6 | 0.013422 s |
| crossed_10 | 0.009341 s |
| mad_5 | 0.008938 s |

See [report.json](report.json) for per-puzzle records. Each puzzle subdirectory contains `solution.txt`, `solution.bff`, and `solution.svg`.

This run covers the 157 primary A/B/C puzzles in the collection. Special-rule levels, source variants, and large synthetic stress cases are outside its scope.
