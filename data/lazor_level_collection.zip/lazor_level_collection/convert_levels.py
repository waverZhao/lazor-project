"""Rebuild the Lazors BFF collection from two pinned public transcriptions.

The halghm4 BFF files are primary. Differing electricg Canvas conversions are
retained as variants. Prism levels remain in raw data and the manifest rather
than receiving an incorrect A/B/C mapping. Source solutions are only replayed
for validation; they are never used to construct inputs or supplied to search.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parent
COMMIT = "63299ad451b4d739a1e9f35fae68f7c184e7fa8f"
REPOSITORY = "https://github.com/electricg/laser-game-canvas"
SOURCE_URL = REPOSITORY + "/blob/" + COMMIT + "/levels.js"
HALGH_REPOSITORY = "https://github.com/halghm4/lazor_solver"
HALGH_COMMIT = "8aef93e9ce75bcdd5d1f5cb626cdacb71006cbe7"
HALGH_DIRECTORY = "boards/all"
SCREENSHOT_REFERENCES = {
    "braid_2": {
        "page_url": "https://www.freeappgg.com/lazors-braid-solutions.html",
        "image_url": "https://www.freeappgg.com/uploads/1/0/1/7/10178123/5065881_orig.png",
        "image_sha256": "eecad7726b7fa8693c2ad260f04cb78d7ed01a3c8770b6ba456ac1d202e258f5",
        "status": "supports_primary_historical_screenshot",
        "inspection": "The changed cell has no placement tile.",
    },
    "showstopper_5": {
        "page_url": "https://www.freeappgg.com/lazors-showstopper-solutions.html",
        "image_url": "https://www.freeappgg.com/uploads/1/0/1/7/10178123/4179584_orig.png",
        "image_sha256": "7ba9b569d472c52bdce7f6c8c9218ffe3659b8fc6883c08253546697f8203e26",
        "status": "supports_primary_historical_screenshot",
        "inspection": "The center has no placement tile.",
    },
    "diagonal_8": {
        "page_url": "https://www.freeappgg.com/lazors-diagonal-solutions.html",
        "image_url": "https://www.freeappgg.com/uploads/1/0/1/7/10178123/6074120_orig.png",
        "image_sha256": "8e4a709cb121393fb1291bcd7eee4e4aa71c688ff92b72ab553f182a1aa4b9e6",
        "status": "unresolved",
        "inspection": "Ray glow obscures the changed cell; preserve both inputs.",
    },
    "crossed_1": {
        "page_url": "https://www.freeappgg.com/lazors-crossed-solutions.html",
        "image_url": "https://www.freeappgg.com/uploads/1/0/1/7/10178123/6382847_orig.png",
        "image_sha256": "d8b35c79d8334770ac911313c4ae2b9868b3974dfb5562d06c417f6727367984",
        "status": "unresolved",
        "inspection": "The bottom-row differences are unclear; preserve both inputs.",
    },
}
TYPE_CODES = {"mirror": "A", "blackhole": "B", "glass": "C"}
DIRECTIONS = {"ne": (1, -1), "nw": (-1, -1),
              "se": (1, 1), "sw": (-1, 1)}


def checksum(path):
    """Return an exact-file hash for provenance and reproducibility."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def position(cell, columns, rows):
    """Translate a one-based, row-major cell ID to zero-based column/row."""
    if type(cell) is not int or not 1 <= cell <= columns * rows:
        raise ValueError("Cell {!r} is outside {}x{}".format(
            cell, columns, rows,
        ))
    row, column = divmod(cell - 1, columns)
    return column, row


def midpoint(record, columns, rows):
    """Translate a named cell face to the BFF half-block coordinate system."""
    column, row = position(record["cell"], columns, rows)
    return {
        "n": (2 * column + 1, 2 * row),
        "s": (2 * column + 1, 2 * row + 2),
        "w": (2 * column, 2 * row + 1),
        "e": (2 * column + 2, 2 * row + 1),
    }[record["side"]]


def convert(level, title):
    """Return an input BFF, removing movable starting positions only."""
    rows, columns = level["rows"], level["columns"]
    if type(rows) is not int or type(columns) is not int:
        raise ValueError("Grid dimensions must be integers")
    if rows < 1 or columns < 1:
        raise ValueError("Grid dimensions must be positive")
    grid = [["o"] * columns for _ in range(rows)]
    inventory = Counter({kind: 0 for kind in "ABC"})
    for cell in level["none"]:
        column, row = position(cell, columns, rows)
        grid[row][column] = "x"
    occupied = set()
    for group in level["cells"]:
        fixed = group["type"].endswith("_stuck")
        kind = TYPE_CODES[group["type"].removesuffix("_stuck")]
        for cell in group["arr"]:
            column, row = position(cell, columns, rows)
            if cell in occupied:
                raise ValueError("Two initial blocks share cell {}".format(cell))
            occupied.add(cell)
            if fixed:
                grid[row][column] = kind
            else:
                inventory[kind] += 1
    if sum(inventory.values()) > sum(row.count("o") for row in grid):
        raise ValueError("Movable inventory exceeds available cells")
    lasers = [
        (*midpoint(laser, columns, rows), *DIRECTIONS[laser["dir"]])
        for laser in level["lasers"]
    ]
    targets = sorted({midpoint(target, columns, rows)
                      for target in level["targets"]})
    if not lasers or not targets:
        raise ValueError("At least one laser and target are required")
    lines = [
        "# Public Canvas transcription of Lazors; not an official data export.",
        "# Source: " + SOURCE_URL,
        "# Level: {} {} (source ID {}:{})".format(
            title, level["l2"], level["l1"], level["l2"],
        ),
        "# Movable initial positions are replaced by inventory counts.",
        "GRID START",
        *(" ".join(row) for row in grid),
        "GRID STOP", "",
        *("{} {}".format(kind, inventory[kind]) for kind in "ABC"),
        "",
        *("L {} {} {} {}".format(*laser) for laser in lasers),
        "",
        *("P {} {}".format(*target) for target in targets),
    ]
    return "\n".join(lines) + "\n", dict(inventory)


def validate_known_placement(level, puzzle, simulate, verify_solution):
    """Check the supplied answer independently; never pass it to a solver."""
    placements = {}
    fixed = {}
    for group in level["solution"]:
        kind = TYPE_CODES[group["type"].removesuffix("_stuck")]
        for cell in group["arr"]:
            point = position(cell, puzzle.width, puzzle.height)
            if point in placements or point in fixed:
                raise ValueError("Two answer blocks share {}".format(point))
            if group["type"].endswith("_stuck"):
                fixed[point] = kind
            else:
                placements[point] = kind
    expected_fixed = {
        (column, row): kind
        for row, cells in enumerate(puzzle.grid)
        for column, kind in enumerate(cells) if kind in "ABC"
    }
    if fixed != expected_fixed:
        raise ValueError("Supplied answer changes fixed blocks")
    result = simulate(puzzle, placements)
    verify_solution(puzzle, result)
    return {
        "status": "passed",
        "targets_hit": len(result.hit_targets),
        "targets_required": len(puzzle.targets),
        "states_processed": result.states_processed,
    }


def normalize_bff_signature(text):
    """Read standard BFF fields for semantic source comparison.

    Comments, whitespace, record ordering, and laser/target ordering do not
    create variants. Unknown records or unsupported symbols are errors.
    This does not simulate or solve a puzzle.
    """
    grid = []
    inventory = {kind: 0 for kind in "ABC"}
    declared = set()
    lasers, targets = [], set()
    started = finished = False
    for raw in text.removeprefix("\ufeff").splitlines():
        tokens = raw.split("#", 1)[0].split()
        if not tokens:
            continue
        if tokens == ["GRID", "START"]:
            if started:
                raise ValueError("Repeated GRID START")
            started = True
            continue
        if tokens == ["GRID", "STOP"]:
            if not started or finished or not grid:
                raise ValueError("Unexpected GRID STOP")
            finished = True
            continue
        if started and not finished:
            if any(value not in ("o", "x", "A", "B", "C")
                   for value in tokens):
                raise ValueError("Unsupported grid symbol")
            if grid and len(tokens) != len(grid[0]):
                raise ValueError("Nonrectangular grid")
            grid.append(tuple(tokens))
            continue
        tag = tokens[0]
        if tag in inventory and len(tokens) == 2:
            if tag in declared:
                raise ValueError("Repeated inventory declaration")
            count = int(tokens[1])
            if count < 0:
                raise ValueError("Negative inventory")
            inventory[tag] = count
            declared.add(tag)
        elif tag == "L" and len(tokens) == 5:
            laser = tuple(map(int, tokens[1:]))
            if any(value not in (-1, 1) for value in laser[2:]):
                raise ValueError("Non-diagonal laser direction")
            lasers.append(laser)
        elif tag == "P" and len(tokens) == 3:
            targets.add(tuple(map(int, tokens[1:])))
        else:
            raise ValueError("Unknown BFF record: " + " ".join(tokens))
    if not started or not finished or not lasers or not targets:
        raise ValueError("Incomplete BFF puzzle")
    width, height = len(grid[0]), len(grid)
    for x, y in [laser[:2] for laser in lasers] + list(targets):
        if not (0 <= x <= 2 * width and 0 <= y <= 2 * height):
            raise ValueError("Point outside the grid")
        if (x + y) % 2 != 1:
            raise ValueError("Point is not a face midpoint")
    if sum(inventory.values()) > sum(row.count("o") for row in grid):
        raise ValueError("Inventory exceeds available cells")
    return {
        "grid": tuple(grid),
        "inventory": tuple(inventory[kind] for kind in "ABC"),
        "lasers": tuple(sorted(lasers)),
        "targets": tuple(sorted(targets)),
    }


def signature_differences(primary, secondary):
    """Describe conflicts explicitly, including every differing grid cell."""
    differences = {}
    if primary["grid"] != secondary["grid"]:
        a, b = primary["grid"], secondary["grid"]
        cells = []
        for row in range(max(len(a), len(b))):
            first = a[row] if row < len(a) else ()
            second = b[row] if row < len(b) else ()
            for column in range(max(len(first), len(second))):
                left = first[column] if column < len(first) else None
                right = second[column] if column < len(second) else None
                if left != right:
                    cells.append({"column": column, "row": row,
                                  "electricg": left, "halghm4": right})
        differences["grid"] = cells
    for name in ("inventory", "lasers", "targets"):
        if primary[name] != secondary[name]:
            differences[name] = {
                "electricg": primary[name], "halghm4": secondary[name],
            }
    return differences


def merge_secondary(entries, directory, output, validator=None, raw_levels=None):
    """Use the pinned BFF source as primary, retaining transcription variants."""
    if not directory.is_dir():
        raise ValueError("Missing raw secondary BFF directory: " + str(directory))
    known = {entry["id"]: entry for entry in entries}
    counts = Counter()
    for path in sorted(directory.glob("*.bff")):
        name = path.stem.lower()
        text = path.read_text(encoding="utf-8-sig")
        signature = normalize_bff_signature(text)
        if validator:
            validator[0](text, source=str(path))
        source = {
            "repository": HALGH_REPOSITORY,
            "commit": HALGH_COMMIT,
            "url": HALGH_REPOSITORY + "/blob/" + HALGH_COMMIT + "/" +
                   HALGH_DIRECTORY + "/" + path.name,
            "raw_file": "raw/halghm4/boards/all/" + path.name,
            "sha256": checksum(path),
        }
        if name in known:
            entry = known[name]
            if not entry.get("output"):
                raise ValueError("Secondary standard BFF conflicts with an "
                                 "unsupported source level ID: " + name)
            destination = output / entry["output"]
            electricg_text = destination.read_text()
            electricg = normalize_bff_signature(electricg_text)
            transcription_source = entry["source"]
            if electricg == signature:
                counts["matches"] += 1
            else:
                relative = Path("variants/electricg") / path.name
                variant = output / relative
                variant.parent.mkdir(parents=True, exist_ok=True)
                variant.write_text(electricg_text)
                entry.setdefault("variants", []).append({
                    "status": "source_conflict", "source": transcription_source,
                    "output": relative.as_posix(),
                    "bff_sha256": checksum(variant),
                    "differences": signature_differences(electricg, signature),
                    "format_validation": "passed",
                    "visual_review": dict(SCREENSHOT_REFERENCES.get(
                        name, {"status": "unresolved"},
                    ), note="Independent historical game screenshot, "
                            "not an official/current dataset authority."),
                })
                counts["variants"] += 1
            entry["secondary_sources"] = [transcription_source]
            entry["source"] = source
            header = ("# Public BFF transcription; not an official game export.\n"
                      "# Source: " + source["url"] + "\n"
                      "# Raw source SHA256: " + source["sha256"] + "\n")
            destination.write_text(header + text)
            entry["bff_sha256"] = checksum(destination)
            entry["format_validation"] = "passed"
            entry["primary_selection"] = (
                "Pinned halghm4 BFF source used consistently; conflicts retained"
            )
            # Recheck the transcription's answer on the chosen primary board.
            # This supplies an existing placement to two simulators, not to search.
            if validator:
                parse, simulate, verify = validator
                puzzle = parse(destination.read_text(), source=str(destination))
                try:
                    entry["answer_validation"] = validate_known_placement(
                        raw_levels[name], puzzle, simulate, verify,
                    )
                except (ValueError, KeyError, AssertionError) as exc:
                    entry["answer_validation"] = {
                        "status": "failed", "reason": str(exc),
                        "note": "Transcription's supplied answer failed on the "
                                "primary board; this does not prove no solution.",
                    }
            entry["answer_validation"]["source"] = transcription_source
            legacy = output / "variants/halghm4" / path.name
            if legacy.exists():
                legacy.unlink()
            continue
        matched = re.fullmatch(r"([a-z_]+)_(\d+)", name)
        if not matched:
            raise ValueError("Unrecognized level filename: " + path.name)
        slug, number = matched.groups()
        relative = Path("levels") / slug / (name + ".bff")
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        header = ("# Public BFF transcription; not an official game export.\n"
                  "# Source: " + source["url"] + "\n"
                  "# Raw source SHA256: " + source["sha256"] + "\n")
        destination.write_text(header + text)
        if normalize_bff_signature(destination.read_text()) != signature:
            raise AssertionError("Source geometry changed while adding comments")
        entries.append({
            "id": name, "pack": slug.title(), "pack_slug": slug,
            "source_id": name, "level_number": int(number),
            "width": len(signature["grid"][0]),
            "height": len(signature["grid"]),
            "inventory": dict(zip("ABC", signature["inventory"])),
            "status": "imported", "output": relative.as_posix(),
            "bff_sha256": checksum(destination), "source": source,
            "unsupported_types": [], "format_validation": "passed",
            "answer_validation": {"status": "not_provided"},
        })
        known[name] = entries[-1]
        counts["additional"] += 1
    return dict(counts)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw", type=Path,
                        default=ROOT / "raw/electricg_levels.json")
    parser.add_argument("--pack-names", type=Path,
                        default=ROOT / "raw/electricg_pack_names.json")
    parser.add_argument("--output", type=Path, default=ROOT)
    parser.add_argument("--additional-bff-dir", type=Path,
                        default=ROOT / "raw/halghm4/boards/all")
    parser.add_argument("--validate-with-project", type=Path,
                        help="Optionally replay source answers with this solver")
    args = parser.parse_args(argv)
    data = json.loads(args.raw.read_text())
    names = json.loads(args.pack_names.read_text())
    entries = []
    validator = None
    if args.validate_with_project:
        project = args.validate_with_project.resolve()
        sys.path.insert(0, str(project))
        sys.path.insert(0, str(project / "tests"))
        from file_io import parse_bff
        from block_laser import simulate
        from compare_algorithms import verify_solution
        validator = parse_bff, simulate, verify_solution
    source = {
        "repository": REPOSITORY, "commit": COMMIT, "url": SOURCE_URL,
        "kind": "public Canvas clone transcription, not official full game",
        "raw_json_sha256": checksum(args.raw),
        "raw_javascript_sha256": checksum(ROOT / "raw/electricg_levels.js"),
        "pack_names_sha256": checksum(args.pack_names),
    }
    for pack_index, pack in enumerate(data):
        title = names[pack_index]["a"]
        slug = re.sub(r"[^a-z0-9]+", "_", title.lower()).strip("_")
        for level in pack:
            types = sorted({group["type"] for group in level["cells"]})
            unsupported = sorted({kind for kind in types
                                  if kind.removesuffix("_stuck") not in TYPE_CODES})
            entry = {
                "id": "{}_{}".format(slug, level["l2"]),
                "pack": title, "pack_slug": slug,
                "source_id": [level["l1"], level["l2"]],
                "width": level["columns"], "height": level["rows"],
                "types": types, "unsupported_types": unsupported,
                "source": {
                    "repository": REPOSITORY, "commit": COMMIT,
                    "url": SOURCE_URL, "raw_file": "raw/electricg_levels.json",
                    "schema_id": [level["l1"], level["l2"]],
                },
                "answer_validation": {"status": "not_checked"},
            }
            entries.append(entry)
            if unsupported:
                entry.update(status="unsupported", output=None,
                             reason="Standard BFF cannot represent: " +
                             ", ".join(unsupported))
                continue
            try:
                text, inventory = convert(level, title)
                relative = Path("levels") / slug / (entry["id"] + ".bff")
                destination = args.output / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_text(text)
                entry.update(status="converted", output=relative.as_posix(),
                             inventory=inventory,
                             bff_sha256=checksum(destination))
                if validator:
                    parse, simulate, verify = validator
                    puzzle = parse(text, source=str(destination))
                    try:
                        entry["answer_validation"] = validate_known_placement(
                            level, puzzle, simulate, verify,
                        )
                    except (ValueError, KeyError, AssertionError) as exc:
                        entry["answer_validation"] = {
                            "status": "failed", "reason": str(exc),
                            "note": "Original supplied answer retained in raw data; "
                                    "this is not a proof the puzzle is unsolvable.",
                        }
            except (ValueError, KeyError) as exc:
                entry.update(status="conversion_error", output=None,
                             reason=str(exc))
    secondary = merge_secondary(
        entries, args.additional_bff_dir, args.output,
        validator,
        {"{}_{}".format(
            re.sub(r"[^a-z0-9]+", "_", names[index]["a"].lower()).strip("_"),
            level["l2"],
        ): level for index, pack in enumerate(data) for level in pack},
    )
    summary = dict(Counter(row["status"] for row in entries))
    summary["total_raw_levels"] = sum(map(len, data))
    summary["electricg_raw_levels"] = sum(map(len, data))
    summary["secondary_raw_bff_files"] = len(
        list(args.additional_bff_dir.glob("*.bff"))
    )
    summary["raw_source_records"] = (
        summary["electricg_raw_levels"] + summary["secondary_raw_bff_files"]
    )
    summary["source_level_ids"] = len(entries)
    summary["primary_bff"] = sum(row["output"] is not None for row in entries)
    summary["variants"] = secondary.get("variants", 0)
    summary["secondary_source_comparison"] = secondary
    summary["known_answer_validation"] = dict(Counter(
        row["answer_validation"]["status"] for row in entries
        if row["status"] in ("converted", "imported")
    ))
    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "coverage": "All 200 entries in the pinned Canvas transcription "
                    "plus standard BFF supplements, with source conflicts "
                    "preserved; not all official Lazors levels.",
        "source": {
            "repository": HALGH_REPOSITORY, "commit": HALGH_COMMIT,
            "directory": HALGH_DIRECTORY,
            "kind": "public BFF transcription, not official game export",
        },
        "source_precedence": "halghm4 standard BFF files are primary; all "
                             "differing electricg conversions are retained.",
        "raw_transcription_source": source,
        "summary": summary, "levels": entries,
        "sources": [{
            "repository": HALGH_REPOSITORY, "commit": HALGH_COMMIT,
            "directory": HALGH_DIRECTORY,
            "kind": "public BFF transcription, not official game export",
        }, source],
    }
    if args.validate_with_project:
        manifest["validator"] = {
            "project": str(project),
            "mode": "Replay supplied answer only; no searching",
            "source_sha256": {
                name: checksum(project / name) for name in (
                    "block_laser.py", "file_io.py",
                    "tests/compare_algorithms.py",
                    "tests/test_search_integration.py",
                )
            },
        }
    args.output.mkdir(parents=True, exist_ok=True)
    path = args.output / "manifest.json"
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(path)
    return int(summary.get("conversion_error", 0) > 0)


if __name__ == "__main__":
    raise SystemExit(main())
