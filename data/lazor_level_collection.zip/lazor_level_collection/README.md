# Lazors BFF Level Dataset

Public level transcriptions and existing BFF files collected for testing the course solver. This dataset contains **157 primary BFF puzzles**, **four source variants**, and the raw data for **52 levels containing prism blocks**. It covers part of the classic game; **coverage of the current official game has not been established**.

## Data and Sources

| Source | Pinned revision | Data used |
| --- | --- | --- |
| [electricg/laser-game-canvas](https://github.com/electricg/laser-game-canvas/blob/63299ad451b4d739a1e9f35fae68f7c184e7fa8f/levels.js) | `63299ad451b4d739a1e9f35fae68f7c184e7fa8f` | Public transcription of 200 levels in 20 packs: 148 support the current A/B/C format and 52 contain prism blocks |
| [halghm4/lazor_solver](https://github.com/halghm4/lazor_solver/tree/8aef93e9ce75bcdd5d1f5cb626cdacb71006cbe7/boards/all) | `8aef93e9ce75bcdd5d1f5cb626cdacb71006cbe7` | 157 existing BFFs used as the primary versions, including six Déjà Vu and three Split levels absent from electricg's collection |

The primary directory consistently uses halghm4's original BFFs with source comments added. The 148 convertible electricg levels provide a cross-check: 144 match the primary puzzles semantically, while four differ. The sources overlap, so their file counts must not be added as independent puzzle counts.

`manifest.json` records **209 source level IDs**: 157 have primary BFFs, and 52 retain their raw data because they require unsupported rules. It also records provenance, status, file hashes, and validation information. Original source files remain in `raw/`.

The sources differ in unavailable cells for `braid_2`, `crossed_1`, `diagonal_8`, and `showstopper_5`. Their electricg conversions are retained in `variants/electricg/`. See [manifest.json](manifest.json) for cell-by-cell differences. These may reflect platform, version, or transcription differences; choosing one primary source does not establish official accuracy.

## Usage

Use Python 3.9 or newer. The converter uses only the Python standard library.

From this directory, regenerate the primary BFFs, variants, and manifest from both pinned sources:

```bash
python3 -B convert_levels.py
```

To replay the source data's supplied answers with the adjacent group project:

```bash
python3 -B convert_levels.py --validate-with-project ../lazor_group_project
```

To search all primary puzzles with the group solver:

```bash
python3 -B ../lazor_group_project/main.py levels/*/*.bff --output-dir results --timeout 60
```

The solver creates a result subdirectory named after each input file. Source variants can be tested separately:

```bash
python3 -B ../lazor_group_project/main.py variants/electricg/*.bff --output-dir results/variants --timeout 60
```

## Included Standard BFF Levels

Each of these **14 packs contains levels 1–10**: Tutorial, Friendly, Vertices, Tricky, Braid, Mad, Yarn, Tiny, Showstopper, Diagonal, Numbered, Darkroom, Crossed, and Grande. Together they contain 140 puzzles.

| Additional pack | Included primary levels |
| --- | --- |
| Tinier | 1–8 |
| Déjà Vu | 1, 3, 5, 6, 8, 10 |
| Split | 2, 5, 8 |

Some levels have been acquired but cannot be converted with the current rules. Electricg's Crystal, Prismatic, Diamond, Glassware, Elementary, and part of Tinier contain prism blocks. Their transcriptions remain in the raw JSON and manifest.

## Conversion Rules

The following mappings apply to electricg's transcription. Primary halghm4 BFFs retain their original puzzle definitions, with provenance comments added.

| Original type | Standard BFF | Behavior |
| --- | --- | --- |
| `mirror` | A | Reflect |
| `blackhole` | B | Absorb |
| `glass` | C | Transmit and reflect |
| Corresponding `_stuck` type | A/B/C within the grid | Fixed block at its original position |
| Original `none` cell | x | Placement forbidden |
| Other available cell | o | Movable blocks may be placed here |

Initial positions of movable blocks are used to count A/B/C inventory. Their cells become available `o` cells in the puzzle input. Fixed blocks remain in the grid, allowing search to rearrange only the movable inventory.

One-based, row-major cell IDs are first converted to zero-based `(column, row)` positions. Sources and targets are then mapped to cell-face midpoints. BFF coordinates start at the top left, with positive x to the right and positive y downward. One coordinate unit is half a cell, and source direction components are `+1` or `-1`.

The original `source_solution` or equivalent answer field is used only for validation after conversion. **It is not used to construct puzzle inputs or supplied to the search algorithm.** Prism levels keep their original representation because mapping them to A/B/C would change their rules.

## Validation Records

All 157 primary BFFs passed the project's reader and format checks. During the initial dataset validation, the histogram-based `targets` solver searched each puzzle with a 3-second budget. **All 157 were solved and independently verified.** That run took approximately **0.312 seconds** in total, with a maximum of approximately **0.023 seconds** per puzzle. Timing included reading and solving, excluding imports, independent replay, and file output. Per-level records are in [validation/solver_check.json](validation/solver_check.json).

The 0.312-second figure belongs to this initial dataset check. Later full output tests are documented separately in the group project's README. Search received only BFF puzzle definitions and did not read the original supplied answers. One successful dataset run does not predict performance on every board or establish official game completeness.

The supplied answers were checked separately. Of the 148 electricg conversions, 144 source answers passed the common simulator and independent optical checks. Four source answers had problems; their original data remain in `raw/`.

The affected levels are `tutorial_5`, `tricky_1`, `tiny_6`, and `showstopper_1`. Problems include incomplete target coverage, an out-of-range cell ID, and overlapping placements. These answer failures do not prove that the puzzles are unsolvable. Those four puzzles and the nine additional halghm4 puzzles were also solved and verified in a separate 13-puzzle check recorded in `validation/`. Replaying an existing answer and searching for one are recorded as distinct checks.

## Coverage Gaps

The [older Pyrosphere website](https://pyrosphere.net/lazors/) lists 280 levels, but its footer is dated ©2013–2017. The [official Steam listing](https://store.steampowered.com/app/341290/Lazors/) describes more than 200 levels. Neither establishes coverage of the current 2026 game.

The [current App Store listing](https://apps.apple.com/us/app/lazors/id386458926) also describes daily puzzles, additional Deluxe content, Portal blocks, Trap targets, and Spin blocks. Complete modern Deluxe and daily-puzzle data have not been collected. Portal, rotation, and avoid-target rules also exceed the course format's A/B/C blocks and ordinary P targets.

Original complete pack data have not been acquired for Portal, Teleport, Wormhole, Plus, Additional, or Positive. Déjà Vu and Split have only the BFF levels listed above. Pack names were cross-checked against the [classic Steam achievement directory](https://truesteamachievements.com/game/Lazors/achievements), which provides names rather than official puzzle data. Missing level numbers were not inferred by subtracting this collection's size from 280.

## File Structure

```text
lazor_level_collection/
├── README.md
├── convert_levels.py       Rebuild BFFs and manifest from pinned sources
├── manifest.json           Provenance, status, hashes, and validation
├── levels/                 157 primary BFFs grouped by level pack
├── variants/electricg/     Four differing source conversions
├── raw/                    Original electricg and halghm4 source data
└── validation/             Answer checks, search records, and verified layouts
```
